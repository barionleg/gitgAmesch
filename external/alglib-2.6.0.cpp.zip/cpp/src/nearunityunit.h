
#ifndef _nearunityunit_h
#define _nearunityunit_h

#include "ap.h"
#include "ialglib.h"

double log1p(double x);


double expm1(double x);


double cosm1(double x);


#endif

