
#ifndef _testldaunit_h
#define _testldaunit_h

#include "ap.h"
#include "ialglib.h"

#include "hblas.h"
#include "reflections.h"
#include "creflections.h"
#include "sblas.h"
#include "ablasf.h"
#include "ablas.h"
#include "ortfac.h"
#include "blas.h"
#include "rotations.h"
#include "hsschur.h"
#include "evd.h"
#include "hqrnd.h"
#include "matgen.h"
#include "trfac.h"
#include "trlinsolve.h"
#include "safesolve.h"
#include "rcond.h"
#include "matinv.h"
#include "lda.h"


bool testlda(bool silent);


/*************************************************************************
Silent unit test
*************************************************************************/
bool testldaunit_test_silent();


/*************************************************************************
Unit test
*************************************************************************/
bool testldaunit_test();


#endif

